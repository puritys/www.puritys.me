(function(){
	window.sample = new sample();
	function sample(){
	
	}
	var o=sample.prototype;
	o.test=function(){
		alert("執行 test function ");
	}
}())